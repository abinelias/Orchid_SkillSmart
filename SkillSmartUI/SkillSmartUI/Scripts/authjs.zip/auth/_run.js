﻿$(function () {
    $.support.cors = true;
    auth.initialize();

    // Activate Knockout
    ko.validation.init({ grouping: { observable: false } });
    ko.applyBindings(auth);
});
