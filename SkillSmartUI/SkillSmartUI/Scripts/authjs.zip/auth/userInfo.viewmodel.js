﻿function UserInfoViewModel(auth, name, dataModel) {
    var self = this;

    // Data
    self.name = ko.observable(name);

    // Operations
    self.logOff = function () {
        dataModel.logout().done(function () {
          auth.navigateToLoggedOff();
        }).fail(function () {
          auth.errors.push("Log off failed.");
        });
    };

    self.manage = function () {
      auth.navigateToManage();
    };
}
