﻿function RegisterExternalViewModel(auth, dataModel) {
    // Private state
    var self = this;

    // Data
    self.loginProvider = ko.observable();
    self.userName = ko.observable(null).extend({ required: true });

    // Other UI state
    self.registering = ko.observable(false);
    self.externalAccessToken = null;
    self.state = null;
    self.loginUrl = null;
    self.errors = ko.observableArray();
    self.validationErrors = ko.validation.group([self.userName]);

    // data-bind click
    self.register = function () {
        self.errors.removeAll();

        if (self.validationErrors().length > 0) {
            self.validationErrors.showAllMessages();
            return;
        }

        self.registering(true);
        dataModel.registerExternal(self.externalAccessToken, {
            userName: self.userName()
        }).done(function (data) {
            sessionStorage["state"] = self.state;
            // IE doesn't reliably persist sessionStorage when navigating to another URL. Move sessionStorage
            // temporarily to localStorage to work around this problem.
            auth.archiveSessionStorageToLocalStorage();
            window.location = self.loginUrl;
        }).failJSON(function (data) {
            var errors;

            self.registering(false);
            errors = dataModel.toErrorsArray(data);

            if (errors) {
                self.errors(errors);
            } else {
                self.errors.push("An unknown error occurred.");
            }
        });
    };
}

auth.addViewModel({
    name: "RegisterExternal",
    bindingMemberName: "registerExternal",
    factory: RegisterExternalViewModel,
    navigatorFactory: function (auth) {
        return function (userName, loginProvider, externalAccessToken, loginUrl, state) {
            auth.errors.removeAll();
            auth.view(auth.Views.RegisterExternal);
            auth.registerExternal().userName(userName);
            auth.registerExternal().loginProvider(loginProvider);
            auth.registerExternal().externalAccessToken = externalAccessToken;
            auth.registerExternal().loginUrl = loginUrl;
            auth.registerExternal().state = state;
        };
    }
});
