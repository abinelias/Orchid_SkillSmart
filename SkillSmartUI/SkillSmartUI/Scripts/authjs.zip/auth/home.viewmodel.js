﻿function HomeViewModel(auth, dataModel) {
    var self = this;

  // HomeViewModel currently does not require data binding, so there are no visible members.
  // Operations
    self.logOff = function () {
      dataModel.logout().done(function () {
        auth.navigateToLoggedOff();
      }).fail(function () {
        auth.errors.push("Log off failed.");
      });
    };
}

auth.addViewModel({
    name: "Home",
    bindingMemberName: "home",
    factory: HomeViewModel
});
