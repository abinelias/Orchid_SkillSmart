﻿using SkillSmart.Base.Entities;
using System.Collections.Generic;
namespace SkillSmart.Base.Services
{
    public interface IOverviewService<T> : IEntityService<T> where T : IEntity
    {
       

    }
}
