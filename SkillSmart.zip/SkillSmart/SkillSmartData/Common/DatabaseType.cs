﻿
namespace SkillSmartData.Common
{
   public static class DataBaseType {
       public const string SKILLSMART_MONGO_DB = "SkillSmart";
       public const string SKILLSMART_MSSQL_DB = "MSSQL";
    }
}
