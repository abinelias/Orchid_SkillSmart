﻿using SkillSmart.Base.Entities;
using System;
namespace SkillSmartSqlDA.Entities
{
    public class SqlEntity : IEntity
    {
        public Guid Id { get; set; }
    }
}
